#!/bin/sh
title Uno v0.0.3.0
java -jar uno.jar
pause