#!/bin/sh
java -jar uno.jar