#!/bin/sh
title Uno v0.0.4.0
java -jar uno.jar
pause