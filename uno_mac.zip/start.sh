#!/bin/sh
title Uno v0.0.5.1
Java -jar Uno.jar
set /p answer=Play Again?[y/n] 
IF /I "%answer%" == "y" goto yes
IF /I "%answer%" == "n" goto no
:yes
cls
Java -jar Uno.jar
set /p answer=Play Again?[y/n] 
IF /I "%answer%" == "y" goto yes
IF /I "%answer%" == "n" goto no
:no
cls